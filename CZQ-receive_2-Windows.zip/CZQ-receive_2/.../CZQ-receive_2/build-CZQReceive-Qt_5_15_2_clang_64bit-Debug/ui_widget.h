/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QWidget *centralWidget;
    QLabel *label;
    QComboBox *BitBox;
    QComboBox *ParityBox;
    QLabel *label_4;
    QLabel *label_6;
    QComboBox *StopBox;
    QPushButton *OpenSerialButton;
    QTextEdit *textEdit;
    QTextEdit *textEdit_2;
    QPushButton *SendButton;
    QLabel *label_5;
    QLabel *label_8;
    QLabel *label_9;
    QComboBox *BaudBox;
    QStackedWidget *stackedSerial;
    QWidget *page;
    QComboBox *PortBox;
    QWidget *page_2;
    QLineEdit *ldPortName;
    QLineEdit *textEdit_5;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;
    QLabel *label_7;
    QPushButton *DrawGraph;
    QCustomPlot *customPlot;
    QCheckBox *automatic;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(1180, 553);
        centralWidget = new QWidget(Widget);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        centralWidget->setGeometry(QRect(20, 110, 601, 391));
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 60, 91, 16));
        BitBox = new QComboBox(centralWidget);
        BitBox->setObjectName(QString::fromUtf8("BitBox"));
        BitBox->setGeometry(QRect(90, 140, 91, 22));
        ParityBox = new QComboBox(centralWidget);
        ParityBox->setObjectName(QString::fromUtf8("ParityBox"));
        ParityBox->setGeometry(QRect(90, 180, 91, 22));
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(10, 180, 91, 16));
        label_6 = new QLabel(centralWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(10, 220, 81, 16));
        StopBox = new QComboBox(centralWidget);
        StopBox->setObjectName(QString::fromUtf8("StopBox"));
        StopBox->setGeometry(QRect(90, 220, 91, 22));
        OpenSerialButton = new QPushButton(centralWidget);
        OpenSerialButton->setObjectName(QString::fromUtf8("OpenSerialButton"));
        OpenSerialButton->setGeometry(QRect(40, 260, 131, 31));
        textEdit = new QTextEdit(centralWidget);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(200, 30, 391, 291));
        textEdit_2 = new QTextEdit(centralWidget);
        textEdit_2->setObjectName(QString::fromUtf8("textEdit_2"));
        textEdit_2->setGeometry(QRect(290, 340, 221, 31));
        SendButton = new QPushButton(centralWidget);
        SendButton->setObjectName(QString::fromUtf8("SendButton"));
        SendButton->setGeometry(QRect(520, 340, 75, 31));
        label_5 = new QLabel(centralWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(0, 330, 131, 41));
        label_8 = new QLabel(centralWidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(10, 140, 91, 16));
        label_9 = new QLabel(centralWidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(10, 100, 81, 16));
        BaudBox = new QComboBox(centralWidget);
        BaudBox->setObjectName(QString::fromUtf8("BaudBox"));
        BaudBox->setGeometry(QRect(90, 100, 91, 22));
        stackedSerial = new QStackedWidget(centralWidget);
        stackedSerial->setObjectName(QString::fromUtf8("stackedSerial"));
        stackedSerial->setGeometry(QRect(90, 50, 91, 31));
        page = new QWidget();
        page->setObjectName(QString::fromUtf8("page"));
        PortBox = new QComboBox(page);
        PortBox->setObjectName(QString::fromUtf8("PortBox"));
        PortBox->setGeometry(QRect(0, 10, 91, 22));
        PortBox->setEditable(true);
        stackedSerial->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QString::fromUtf8("page_2"));
        ldPortName = new QLineEdit(page_2);
        ldPortName->setObjectName(QString::fromUtf8("ldPortName"));
        ldPortName->setGeometry(QRect(10, 10, 71, 21));
        stackedSerial->addWidget(page_2);
        textEdit_5 = new QLineEdit(centralWidget);
        textEdit_5->setObjectName(QString::fromUtf8("textEdit_5"));
        textEdit_5->setGeometry(QRect(80, 340, 113, 31));
        mainToolBar = new QToolBar(Widget);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        mainToolBar->setGeometry(QRect(0, 0, 4, 14));
        statusBar = new QStatusBar(Widget);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        statusBar->setGeometry(QRect(0, 0, 3, 20));
        label_7 = new QLabel(Widget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(10, 20, 341, 91));
        label_7->setPixmap(QPixmap(QString::fromUtf8(":/1.png")));
        DrawGraph = new QPushButton(Widget);
        DrawGraph->setObjectName(QString::fromUtf8("DrawGraph"));
        DrawGraph->setGeometry(QRect(530, 500, 75, 31));
        customPlot = new QCustomPlot(Widget);
        customPlot->setObjectName(QString::fromUtf8("customPlot"));
        customPlot->setGeometry(QRect(620, 110, 491, 371));
        automatic = new QCheckBox(Widget);
        automatic->setObjectName(QString::fromUtf8("automatic"));
        automatic->setGeometry(QRect(620, 50, 131, 16));
#if QT_CONFIG(shortcut)
        label_4->setBuddy(ParityBox);
        label_6->setBuddy(StopBox);
        label_8->setBuddy(BitBox);
#endif // QT_CONFIG(shortcut)

        retranslateUi(Widget);

        BitBox->setCurrentIndex(-1);
        BaudBox->setCurrentIndex(-1);
        stackedSerial->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QCoreApplication::translate("Widget", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("Widget", "serial_port", nullptr));
        label_4->setText(QCoreApplication::translate("Widget", "check_bite", nullptr));
        label_6->setText(QCoreApplication::translate("Widget", "stop_bite", nullptr));
        OpenSerialButton->setText(QCoreApplication::translate("Widget", "open_serial", nullptr));
        SendButton->setText(QCoreApplication::translate("Widget", "send", nullptr));
        label_5->setText(QCoreApplication::translate("Widget", "Duty_Circle", nullptr));
        label_8->setText(QCoreApplication::translate("Widget", "data_bites", nullptr));
        label_9->setText(QCoreApplication::translate("Widget", "baud_rate", nullptr));
        BaudBox->setCurrentText(QString());
        ldPortName->setText(QCoreApplication::translate("Widget", "/dev/ttys001", nullptr));
        label_7->setText(QString());
        DrawGraph->setText(QCoreApplication::translate("Widget", "Draw", nullptr));
        automatic->setText(QCoreApplication::translate("Widget", "automatic mode", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
