#include "Qcurve.h"

Qcurve::Qcurve()
{
    this->legend->setVisible(true);

    QSharedPointer<QCPAxisTickerDateTime> dateTick(new QCPAxisTickerDateTime);
    dateTick->setDateTimeFormat("hh:mm:ss");
    this->yAxis2->setVisible(true);//显示y轴2
    this->xAxis2->setVisible(true);//显示x轴2
    this->axisRect()->setBackground(QBrush(Qt::black));//背景黑色
    this->xAxis->grid()->setPen(QPen(QColor(180, 180, 180), 1, Qt::PenStyle::DashLine));//网格白色虚线
    this->yAxis->grid()->setPen(QPen(QColor(180, 180, 180), 1, Qt::PenStyle::DashLine));//网格白色虚线
    this->xAxis->grid()->setSubGridPen(QPen(QColor(50, 50, 50), 1, Qt::DotLine));//网格浅色点线
    this->yAxis->grid()->setSubGridPen(QPen(QColor(50, 50, 50), 1, Qt::DotLine));//网格浅色点线
    this->xAxis->grid()->setSubGridVisible(true);//显示x轴子网格线
    this->yAxis->grid()->setSubGridVisible(true);//显示要轴子网格线

    // 边框右侧和上侧均显示刻度线，但不显示刻度值:
    this->xAxis2->setVisible(true);
    this->xAxis2->setTickLabels(false);
    this->yAxis2->setVisible(true);
    this->yAxis2->setTickLabels(false);

    this->xAxis->setTicker(dateTick);

}

void Qcurve::tick()
{
    this->replot();
}

/*bool addCurve(QString linename)
{
    if(!mGraph.contains(linename))
    {
        QPointer<QCPGraph> graph = this->addGraph(this->xAxis,this->yAxis);
        graph->setName(linename);
        colorindex++;
        colorindex = colorindex%18;
        QPen pen = QPen(baseColors[colorindex]);
        pen.setWidth(m_width);
        graph->setPen(pen);
        mGraph.insert(linename,graph);
        return true;
    }
    else
        return false;
}*/
