#ifndef QCURVE_H
#define QCURVE_H
#include <qcustomplot.h>
#include <QMap>
#include <QString>
#include <QPointer>
#include <QTimer>
#include <QTime>

class Qcurve : QCustomPlot
{
private:
    QMap<QString, QPointer<QCPGraph>> mGraph;
    QTimer timerTick;

public:
    Qcurve();

    void tick();
};

#endif // QCURVE_H
