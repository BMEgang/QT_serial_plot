#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include<QString>
#include<QDebug>
#include<QString>
#include<QFileDialog>
#include <QGridLayout>
#include <QTimer>
#include <QSplineSeries>
#include <QValueAxis>
#include <QHBoxLayout>
#include <qmath.h>
#include <QStack>
#include <QQueue>
#include <QVector>
#include <QTimer>
#include <QTime>
#include <QElapsedTimer>
#include <qcustomplot.h>
#include <QThread>

#include "myserialcontroller.h"

QT_CHARTS_USE_NAMESPACE


QT_BEGIN_NAMESPACE
namespace Ui
{
    class Widget;
}
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);

    ~Widget();

    int Extraction_numbers(QString s);

    void ReadData();

    void CalculateFunction();

    void setupRealtimeDataDemo();//设置qcustomplot画图属性，实时

    void SimpleDemo(QCustomPlot *customPlot,double n);

    bool equal(double a, double b);

    static bool isFastClick(QObject *target, int delayTimeMil);

signals:
    void serialWrite(const QString& mesg);
    void serialOpen(const SerialSetting& setting);
    void serialClose();

private slots:
//    void on_OpenSerialButton_clicked();

    void on_SendButton_clicked();

    void on_DrawGraph_clicked();

    void realtimeDataSlot();

    void send_command();

    void on_automatic_stateChanged(int arg1);

    //////////////////////////////////
    /// ADD by YWH
    ////////////////////////////////////

    void on_serialOpened();
    void on_serialClosed();
    void on_serialError(const QString& log);

    void on_getDutyResult(const double& res);

    void on_timeoutForReply();

    void on_logAppend(const QString& log);
    void on_serialData(const QByteArray& data);

    // 修改了en_SendButton_clicked();

private:
    Ui::Widget *ui;
    QSerialPort *serial;
    bool calculated_flag;
    bool flag;

    QStack<double> result;
    QQueue<double> queue;
    int readtimes;
    QTimer dataTimer;
    QTimer dataTimer2;
    QElapsedTimer t;
    QElapsedTimer t1;

    double tempnum[11];
    double n;

    /// ADD by YWH
    QTimer* mTimer = nullptr;
    QTimer* mSendTimer = nullptr;
    MySerialController* mSerialController = nullptr;
    QThread* mSerialThread = nullptr;
    bool isWriteCommand = false;
    bool isSerialOpened = false;
};
#endif // WIDGET_H
