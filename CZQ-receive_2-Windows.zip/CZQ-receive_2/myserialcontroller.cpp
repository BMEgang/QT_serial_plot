#include "myserialcontroller.h"

#include <QDateTime>
#include <QMessageBox>
#include <QSerialPortInfo>
#include <QtDebug>

MySerialController::MySerialController() : SerialController() {
  buffer.clear();

  mSupport.baudRates = QSerialPortInfo::standardBaudRates();
  //  mSupport.baudRates = {QSerialPort::Baud4800, QSerialPort::Baud9600,
  //                        QSerialPort::Baud19200, QSerialPort::Baud115200};
  mSupport.dataBits = {QSerialPort::Data8, QSerialPort::Data7};
  mSupport.stopBits = {QSerialPort::OneStop, QSerialPort::TwoStop};
  mSupport.checkBits = {QSerialPort::NoParity, QSerialPort::OddParity,
                        QSerialPort::EvenParity};
}

void MySerialController::processRawData(const QByteArray &raw) {
  QString string = QString::fromUtf8(raw);

  for (auto line : string.split('\n')) {
    if (line == "START SEQUENCE") {
      isCalculate = true;
      p = t = 0;
      pCount = tCount = 0;
    }

    if (isCalculate == true) {
      if (line.contains("P:")) {
        p += extractionNumbers(line);
        pCount++;
      } else if (line.contains("T:")) {
        t += extractionNumbers(line);
        tCount++;
      }
    }

    if (line == "END MEASUREMENT") {
      isCalculate = false;

      if (pCount != tCount) {
        qDebug() << "ERROR: periods and tons have different number";
      }
      p = p / pCount;
      t = t / tCount;

      emit dutyResult(t / p);

      if (!mFile->open(QIODevice::Text | QIODevice::WriteOnly| QIODevice::Append)) {
          qDebug()<< "Can not open output file to write data";
      } else {
        mFile->write(QString(QString::number(t / p, 'f') + "\n").toUtf8());
        mFile->waitForBytesWritten(100);
        mFile->close();
      }

      p = t = 0;
      pCount = tCount = 0;
    }
  }
}

void MySerialController::childInit() {
  mFile = new QFile();
  mFile->setFileName("./" + QDateTime::currentDateTime().toString("MM-dd-hh:mm")+".log");
  if (!mFile->open(QIODevice::Text | QIODevice::WriteOnly | QIODevice::Truncate)) {
      qDebug()<< "Can not open output file";
  }else{
      mFile->close();
  }
}

int MySerialController::extractionNumbers(QString s) {
  QString tmp;

  for (int j = 0; j < s.length(); j++) {
    if (s[j] >= '0' && s[j] <= '9') {
      tmp.append(s[j]);
    }
  }

  return tmp.toDouble();
}
