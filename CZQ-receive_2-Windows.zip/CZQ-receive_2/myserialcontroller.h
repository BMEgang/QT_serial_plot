#ifndef MYSERIALCONTROLLER_H
#define MYSERIALCONTROLLER_H

#include "serialcontroller.h"
#include <QFile>

class MySerialController : public SerialController
{
    Q_OBJECT
public:
    MySerialController();
    ~MySerialController(){};

protected:
    void  processRawData(const QByteArray& raw) override;
    void childInit() override;

signals:
    void dutyResult(const double& res);

private:
    QStringList buffer;

    bool isCalculate = false;
    double p = 0;
    double t = 0;
    int pCount = 0;
    int tCount = 0;

    QFile* mFile = nullptr;

    int extractionNumbers(QString s);
};

#endif // MYSERIALCONTROLLER_H
