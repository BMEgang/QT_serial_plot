#ifndef SERIALCONTROLLER_H
#define SERIALCONTROLLER_H

#include <QObject>
#include <QSerialPort>
#include <QThread>

QString SerialTerms(const QSerialPort::BaudRate& baud);

QString SerialTerms(const qint32& baud);

QString SerialTerms(const QSerialPort::DataBits& bits);

QString SerialTerms(const QSerialPort::StopBits& stops);

QString SerialTerms(const QSerialPort::Parity& stops);


struct SerialSupport{
    QList<qint32> baudRates;
    QList<QSerialPort::DataBits> dataBits;
    QList<QSerialPort::Parity> checkBits;
    QList<QSerialPort::StopBits> stopBits;
};

struct SerialSetting{
    QString portName;
    int baudRate;
    int dataBit;
    int checkBit;
    int stopBit;
};


class SerialController : public QObject
{
    Q_OBJECT
public:
    explicit SerialController();
    virtual ~SerialController();

    QList<qint32> getSupportedBauds() const {return mSupport.baudRates;}
    QList<QSerialPort::DataBits> getSupportedDatabits() const {return mSupport.dataBits;}
    QList<QSerialPort::Parity> getSupportedParities() const {return mSupport.checkBits;}
    QList<QSerialPort::StopBits> getSupportedStopbits() const {return mSupport.stopBits;}


public slots:
    void init();
    void open(const SerialSetting& setting);
    void close();

    void write(const QString& mesg);


signals:
    void serialOpenned();
    void serialClosed();
    void serialError(const QString& errorLog);

    void serialData(const QByteArray& data);

protected:
    SerialSupport mSupport;

    virtual void processRawData(const QByteArray& raw) = 0;
    virtual void childInit() {}

private:
    QSerialPort *mSerial = nullptr;

private slots:
    void on_readSerial();
};

#endif // SERIALCONTROLLER_H
