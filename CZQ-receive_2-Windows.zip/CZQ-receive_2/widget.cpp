#include "widget.h"
#include "QFile"
#include "QTextStream"
#include "ui_widget.h"
#include <QDebug>
#include <QMessageBox>
#include <QSharedPointer>
#include <QThread>
#include <QVector>
#include <QtCharts/QChart>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <QtCharts/QValueAxis>
#include <QtGlobal>

Widget::Widget(QWidget *parent)
    : QWidget(parent), ui(new Ui::Widget), mTimer(new QTimer(this)),
      mSendTimer(new QTimer(this)) {
  flag = false;            //设置标志位，防止没开串口就按发送键
  calculated_flag = false; //只有这个标志位是真的时候才会计算

  ui->setupUi(this);

  setWindowTitle("CZQReceive"); //设置窗口栏目名字
  setWindowFlags(windowFlags() &
                 ~Qt::WindowMinMaxButtonsHint); // 去掉最大化最小化按键
  this->setFixedSize(this->width(), this->height()); //固定窗口大小
  ui->textEdit_2->setText("S_1\n");                  // 预先设置输入框
  ui->SendButton->setDisabled(true);
  ui->textEdit_2->setDisabled(true);
  ui->automatic->setDisabled(true);

  //查找可用的串口
  // 不需要每个串口开关一下测试串口是否正常，一切由用户决定
  foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts()) {
    QSerialPort serial;
    serial.setPort(info);
    ui->PortBox->addItem(serial.portName());
  }

  //////////////////////////////////////////
  /// Serial
  mSerialController = new MySerialController;

  for (auto baud : mSerialController->getSupportedBauds()) {
    ui->BaudBox->addItem(SerialTerms(baud));
  }
  for (auto databit : mSerialController->getSupportedDatabits()) {
    ui->BitBox->addItem(SerialTerms(databit));
  }
  for (auto stopbit : mSerialController->getSupportedStopbits()) {
    ui->StopBox->addItem(SerialTerms(stopbit));
  }
  for (auto parity : mSerialController->getSupportedParities()) {
    ui->ParityBox->addItem(SerialTerms(parity));
  }

  //设置波特率下拉菜单默认显示第0项
  ui->BaudBox->setCurrentIndex(8);
  ui->textEdit->setReadOnly(true);
  ui->textEdit_5->setReadOnly(true);

  mSerialThread = new QThread;
  mSerialController->moveToThread(mSerialThread);
  connect(mSerialThread, &QThread::started, mSerialController,
          &MySerialController::init);
  connect(mSerialThread, &QThread::destroyed, mSerialController,
          &MySerialController::deleteLater);

  connect(this, &Widget::serialOpen, mSerialController,
          &MySerialController::open);
  connect(this, &Widget ::serialClose, mSerialController,
          &MySerialController::close);
  connect(ui->OpenSerialButton, &QPushButton::clicked, [=]() {
    if (!isSerialOpened) {
      SerialSetting setting;
      //      if (ui->stackedSerial->currentIndex() == 0) {
      setting.portName = ui->PortBox->currentText();
      //      } else if (ui->stackedSerial->currentIndex() == 1) {
      //        setting.portName = ui->ldPortName->text();
      //      }
      setting.baudRate = ui->BaudBox->currentIndex();
      setting.dataBit = ui->BitBox->currentIndex();
      setting.stopBit = ui->StopBox->currentIndex();
      setting.checkBit = ui->ParityBox->currentIndex();
      emit serialOpen(setting);
    } else {
      emit serialClose();
    }
  });
  connect(mSerialController, &MySerialController::serialOpenned, this,
          &Widget::on_serialOpened);
  connect(mSerialController, &MySerialController::serialClosed, this,
          &Widget::on_serialClosed);

  connect(this, &Widget::serialWrite, mSerialController,
          &MySerialController::write);

  connect(mSerialController, &MySerialController::dutyResult, this,
          &Widget::on_getDutyResult);
  // Get serial raw
  connect(mSerialController, &MySerialController::serialData, this,
          &Widget::on_serialData);

  mSerialThread->start();

  //  // change portname input method
  //  connect(ui->btnPortChange, &QPushButton::clicked, [=]() {
  //    int currentIndex = ui->stackedSerial->currentIndex();
  //    int nextIndex = -1;

  //    if (currentIndex == 0)
  //      nextIndex = 1;
  //    else if (currentIndex == 1)
  //      nextIndex = 0;

  //    ui->stackedSerial->setCurrentIndex(nextIndex);
  //  });
  /// Serial END
  //////////////////////////////////////////////

  for (int i = 0; i < 11; i++) {
    tempnum[i] = 0;
  }
  n = 0;

  mTimer->setSingleShot(true);
  mTimer->setInterval(7000);
  connect(mTimer, &QTimer::timeout, this, &Widget::on_timeoutForReply);

  mSendTimer->setSingleShot(true);
  mSendTimer->setInterval(500);
  connect(mSendTimer, &QTimer::timeout, this, &Widget::on_SendButton_clicked);

  // connect(ui->textEdit_5, SIGNAL(textChanged()), this,
  // SLOT(realtimeDataSlot()));

  // ui->customPlot->replot();
}

Widget::~Widget() {
  delete ui;
  mSerialThread->quit();
  mSerialThread->wait(3000);
  if (mSerialThread->isRunning()) {
    mSerialThread->terminate();
  }
  delete mSerialThread;
}

/****************************设置串口********************************************************************************************************************************************/

// void Widget::on_OpenSerialButton_clicked() {
//  if (ui->OpenSerialButton->text() == tr("open_serial")) {
//    flag = true;
//    serial = new QSerialPort;
//    //设置串口名
//    serial->setPortName(ui->PortBox->currentText());
//    //打开串口
//    serial->open(QIODevice::ReadWrite);

//    //设置波特率
//    switch (ui->BaudBox->currentIndex()) {
//    case 0:
//      serial->setBaudRate(QSerialPort::Baud1200);

//      break;
//    case 1:
//      serial->setBaudRate(QSerialPort::Baud2400);

//      break;
//    case 2:
//      serial->setBaudRate(QSerialPort::Baud4800);

//      break;
//    case 3:
//      serial->setBaudRate(QSerialPort::Baud9600);

//      break;
//    case 4:
//      serial->setBaudRate(QSerialPort::Baud19200);

//      break;
//    case 5:
//      serial->setBaudRate(QSerialPort::Baud38400);

//      break;
//    case 6:
//      serial->setBaudRate(QSerialPort::Baud57600);

//      break;
//    case 7:
//      serial->setBaudRate(QSerialPort::Baud115200);

//      break;
//    default:

//      break;
//    }

//    //设置数据位数

//    switch (ui->BitBox->currentIndex()) {
//    case 0:
//      serial->setDataBits(QSerialPort::Data8); //设置数据位8
//      break;
//    default:
//      break;
//    }
//    //设置校验位
//    switch (ui->ParityBox->currentIndex()) {
//    case 0:
//      serial->setParity(QSerialPort::NoParity);
//      break;
//    default:
//      break;
//    }
//    //设置停止位
//    switch (ui->BitBox->currentIndex()) {
//    case 0:
//      serial->setStopBits(QSerialPort::OneStop); //停止位设置为1
//      break;
//    case 1:
//      serial->setStopBits(QSerialPort::TwoStop);
//    default:
//      break;
//    }
//    //设置流控制
//    serial->setFlowControl(QSerialPort::NoFlowControl); //设置为无流控制

//    //关闭设置菜单使能
//    ui->PortBox->setEnabled(false);
//    ui->BaudBox->setEnabled(false);
//    ui->BitBox->setEnabled(false);
//    ui->ParityBox->setEnabled(false);
//    ui->StopBox->setEnabled(false);
//    ui->OpenSerialButton->setText(tr("close_serial"));
//    ui->SendButton->setDisabled(false); //可以开始发送了
//    ui->textEdit_2->setDisabled(false);
//    ui->automatic->setDisabled(false);

//    //连接信号槽
//    QObject::connect(serial, &QSerialPort::readyRead, this,
//    &Widget::ReadData);

//    // dataTimer2.start(7000);
//  } else {
//    //关闭串口
//    serial->clear();
//    serial->close();
//    serial->deleteLater();

//    //恢复设置使能
//    ui->PortBox->setEnabled(true);
//    ui->BaudBox->setEnabled(true);
//    ui->BitBox->setEnabled(true);
//    ui->ParityBox->setEnabled(true);
//    ui->StopBox->setEnabled(true);
//    ui->OpenSerialButton->setText(tr("open_serial"));
//    flag = false;
//    ui->SendButton->setDisabled(true);
//    ui->textEdit_2->setDisabled(true);
//    ui->automatic->setDisabled(true);

//    dataTimer.stop();
//  }
//}

//读取接收到的信息并且储存
void Widget::ReadData() {
  QByteArray buf;
  QFile myfile("test.txt"); //创建一个输出文件的文档

  buf = serial->readAll();

  if ((!buf.isEmpty()) &&
      (myfile.open(
          QFile::WriteOnly |
          QFile::
              Truncate))) //注意WriteOnly是往文本中写入的时候用，ReadOnly是在读文本中内容的时候用，Truncate表示将原来文件中的内容清空
  {
    QTextStream out(&myfile);
    QString str = ui->textEdit->toPlainText();

    str += tr(buf);

    ui->textEdit->clear();
    ui->textEdit->append(str);
    out << ui->textEdit->toPlainText() << Qt::endl;

    buf.clear();
    myfile.close();
  }

  CalculateFunction(); //计算占空比
}

void Widget::CalculateFunction() {
  QString fileName = "test.txt";
  double Period = 0;
  double Ton = 0;
  queue.clear();

  if ((fileName.isEmpty())) //如果文件名为空，即返回
  {
    QMessageBox::information(NULL, "ERROR", "no these files exit");
    return;
  }

  QFile inputFile(fileName);

  if (inputFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
    QTextStream in(&inputFile);

    while (!in.atEnd()) {
      QString line = in.readLine();

      if (line == "START SEQUENCE") {
        calculated_flag = true;
      }

      if (calculated_flag == true) {
        if (line.contains("P:")) {
          Period += Extraction_numbers(line);
        } else if (line.contains("T:")) {
          Ton += Extraction_numbers(line);
        }
      }

      if (line == "END MEASUREMENT") {
        calculated_flag = false;
        Period = Period / 20;
        Ton = Ton / 20;
        result.push(Ton / Period);

        //可以尝试定义标志位，如果两者相等的话那么就不用画图了，如果不等再刷新图
        // double k = ui->textEdit_5->toPlainText().toDouble();

        // equal_flag = equal(result.top(),k);

        ui->textEdit_5->setText(QString::number(result.top()));

        queue.enqueue(result.top());

        Period = 0;
        Ton = 0;
      }
    }
    inputFile.close();
  } else {
    QMessageBox::information(NULL, "ERROR", "cannot open file!");
    return;
  }
}

//发送按钮槽函数
void Widget::on_SendButton_clicked() {
  //  if (serial->isOpen()) {
  //    if (!ui->automatic->isChecked()) {
  //      bool res = isFastClick(ui->SendButton, 1000); //防止按钮被失手多次按下
  //      qDebug() << "res:" << res << Qt::endl;

  //      if (!res) {
  //        serial->write(ui->textEdit_2->toPlainText().toUtf8());

  //        realtimeDataSlot();
  //      }

  //    } else {
  //      serial->write(ui->textEdit_2->toPlainText().toUtf8());
  //      t.start();
  //      while (t.elapsed() < 1200)
  //        ;
  //    }
  //  }

  ///////////////////////////////////////////////
  /// Write by YWH
  ///////////////////////////////////////////////

  if (isWriteCommand) {
    ui->textEdit->append("Send too fast");
    return;
  }

  QString input = ui->textEdit_2->toPlainText();
  if (input.isEmpty()) {
    ui->textEdit->append("Please enter command\n");
    return;
  }
  emit serialWrite(input);
  isWriteCommand = true;

  // Start Timer for stopping pushing button too fast
  // and waiting for reply
  mTimer->start();
}

int Widget::Extraction_numbers(QString s) {
  QString tmp;

  for (int j = 0; j < s.length(); j++) {
    if (s[j] >= '0' && s[j] <= '9') {
      tmp.append(s[j]);
    }
  }

  return tmp.toDouble();
}

void Widget::on_DrawGraph_clicked() {

  int i = 0;

  QLineSeries *series = new QLineSeries();
  QChart *chart = new QChart();


  for (auto iQ = queue.begin(), end = queue.end(); iQ != end; ++iQ) {
    i++;
    series->append(i, *iQ);
  }

  chart->legend()->hide(); //隐藏图例

  chart->addSeries(series); //关联series

  series->setUseOpenGL(true); //开启OpenGL

  chart->createDefaultAxes(); //设置默认坐标系

  //创建坐标
  QValueAxis *axisX = new QValueAxis; // X 轴
  axisX->setTitleText("sequence");    //标题

  QValueAxis *axisY = new QValueAxis; // Y 轴
  axisY->setTitleText("value");

  //为序列设置坐标轴
  chart->setAxisX(axisX, series);
  chart->setAxisY(axisY, series);

  // chart->setTitle(QStringLiteral(""));

  QChartView *view = new QChartView(chart);

  view->setRenderHint(QPainter::Antialiasing);
  view->resize(400, 300);

  view->show();
}

void Widget::send_command() { on_SendButton_clicked(); }

void Widget::realtimeDataSlot() {
  // qDebug()<<"duty_cycle textEdit is called"<<endl;

  QString strTxtEdt = ui->textEdit_5->text();
  n = strTxtEdt.toDouble();
  SimpleDemo(ui->customPlot, n);
}

void Widget::SimpleDemo(QCustomPlot *customPlot, double n) {

  QVector<double> temp(11);
  QVector<double> temp1(11);
  for (int i = 0; i < 10; i++) {
    tempnum[i] = tempnum[i + 1];
  }
  tempnum[10] = n;
  for (int i = 0; i < 11; i++) {
    temp[i] = i;
    temp1[i] = tempnum[i];
  }

  qDebug() << "************************new turn "
              "begin*********************************"
           << Qt::endl;
  qDebug() << "n:" << n << Qt::endl;
  qDebug() << "temp" << temp << Qt::endl;
  qDebug() << "temp1" << temp1 << Qt::endl;
  qDebug()
      << "************************new turn end*********************************"
      << Qt::endl;

  customPlot->addGraph(); // black line
  customPlot->graph(0)->setPen(QPen(Qt::black));
  customPlot->graph(0)->setName("duty_cycle");

  ui->customPlot->yAxis2->setVisible(true); //显示y轴2
  ui->customPlot->xAxis2->setVisible(true); //显示x轴2

  // 边框右侧和上侧均显示刻度线，但不显示刻度值:
  ui->customPlot->xAxis2->setVisible(true);
  ui->customPlot->xAxis2->setTickLabels(false);
  ui->customPlot->yAxis2->setVisible(true);
  ui->customPlot->yAxis2->setTickLabels(false);

  ui->customPlot->axisRect()->setupFullAxesBox();
  customPlot->graph(0)->setData(temp, temp1);
  customPlot->xAxis->setLabel("sequence");
  customPlot->yAxis->setLabel("value");
  customPlot->xAxis->setRange(0, 11);
  customPlot->xAxis->setSubTickLength(1);
  customPlot->yAxis->setRange(0, 1);

  customPlot->graph(0)->rescaleAxes(); //自动调节坐标轴

  customPlot->replot(); //重新绘图
}

bool Widget::equal(double a, double b) {
  if ((a - b > -0.00001) && (a - b) < 0.00001)
    return true;
  else
    return false;
}

void Widget::on_automatic_stateChanged(int arg1) {
  //  if ((arg1 == Qt::Checked) && (serial->isOpen())) // "选中"
  //  {
  //    connect(&dataTimer, SIGNAL(timeout()), this, SLOT(send_command()));
  //    connect(&dataTimer, SIGNAL(timeout()), this, SLOT(realtimeDataSlot()));
  //    dataTimer.start(8000);
  //  } else if (arg1 == Qt::Unchecked) {
  //    dataTimer.stop();
  //  }

  if ((arg1 == Qt::Checked) && isSerialOpened) // "选中"
  {
    on_SendButton_clicked();
  } else if (arg1 == Qt::Unchecked) {
  }
}

void Widget::on_serialOpened() {

  //关闭设置菜单使能
  ui->PortBox->setEnabled(false);
  ui->BaudBox->setEnabled(false);
  ui->BitBox->setEnabled(false);
  ui->ParityBox->setEnabled(false);
  ui->StopBox->setEnabled(false);
  ui->OpenSerialButton->setText(tr("close_serial"));
  ui->SendButton->setDisabled(false); //可以开始发送了
  ui->textEdit_2->setDisabled(false);
  ui->automatic->setDisabled(false);
  ui->textEdit->append("Serial Opened");

  isSerialOpened = true;

  /// Check if auto_send
  if (ui->automatic->isChecked()) {
    on_SendButton_clicked();
  }
}

void Widget::on_serialClosed() {
  //恢复设置使能
  ui->PortBox->setEnabled(true);
  ui->BaudBox->setEnabled(true);
  ui->BitBox->setEnabled(true);
  ui->ParityBox->setEnabled(true);
  ui->StopBox->setEnabled(true);
  ui->OpenSerialButton->setText(tr("open_serial"));
  ui->SendButton->setDisabled(true);
  ui->textEdit_2->setDisabled(true);
  ui->automatic->setDisabled(true);

  ui->textEdit->append("Serial Closed");

  isSerialOpened = false;
}

void Widget::on_serialError(const QString &log) {
  ui->textEdit->append("Serial ERROR: " + log + "\n");
}

void Widget::on_getDutyResult(const double &res) {
  mTimer->stop();
  isWriteCommand = false;

  result.push(res);

  ui->textEdit_5->setText(QString::number(result.top()));

  queue.enqueue(result.top());

  // show res
  SimpleDemo(ui->customPlot, res);

  // if autometic send is set
  if (ui->automatic->isChecked()) {
    mSendTimer->start();
  }
}

void Widget::on_timeoutForReply() {
  ui->textEdit->append("Instrument do not reply in: " +
                       QString::number(mTimer->interval()) + " ms\n");

  isWriteCommand = false;
}

void Widget::on_logAppend(const QString &log) { ui->textEdit->append(log); }

void Widget::on_serialData(const QByteArray &data) {
  ui->textEdit->append(QString::fromUtf8(data));
}

bool Widget::isFastClick(QObject *target, int delayTimeMil) //判断是否是快速按键
{
  //  qlonglong lastTick = (target->property("tick").toLongLong());
  //  qlonglong tick = GetTickCount();
  //  target->setProperty("tick", tick);
  //  if (tick - lastTick > delayTimeMil) {
  //    return false;
  //  }
  //  return true;
  return true;
}
