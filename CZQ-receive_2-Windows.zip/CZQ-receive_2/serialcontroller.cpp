#include "serialcontroller.h"
#include <QSerialPortInfo>

QString SerialTerms(const QSerialPort::BaudRate &baud) {
  return QString::number(baud, 10);
}

QString SerialTerms(const qint32 &baud) { return QString::number(baud, 10); }

QString SerialTerms(const QSerialPort::DataBits &bits) {
  if (bits == QSerialPort::UnknownDataBits)
    return "Unknown";
  return QString::number(bits, 10);
}

QString SerialTerms(const QSerialPort::StopBits &stops) {
  switch (stops) {
  case QSerialPort::OneStop:
    return "1";
  case QSerialPort::TwoStop:
    return "2";
  case QSerialPort::OneAndHalfStop:
    return "1.5";
  case QSerialPort::UnknownStopBits:
    return "Unknow";
  }
}

QString SerialTerms(const QSerialPort::Parity &parity) {
  switch (parity) {
  case QSerialPort::NoParity:
    return "None";
  case QSerialPort::EvenParity:
    return "Even";
  case QSerialPort::OddParity:
    return "Odd";
  case QSerialPort::UnknownParity:
    return "Unknow";
  case QSerialPort::SpaceParity:
    return "Space";
  case QSerialPort::MarkParity:
    return "Mark";
  }
}

SerialController::SerialController()  {
  qRegisterMetaType<SerialSetting>("SerialSetting");

  //  mSupport.baudRates = QSerialPortInfo::standardBaudRates();
  //  mSupport.dataBits = {QSerialPort::Data8};
  //  mSupport.checkBits = {QSerialPort::NoParity};
  //  mSupport.stopBits = {QSerialPort::OneStop};
}

SerialController::~SerialController() {
  if (!mSerial) {
    if (mSerial->isOpen())
      mSerial->close();
    delete mSerial;
  }
}

void SerialController::init() {
  // connect QThread::started() to this init()
  mSerial = new QSerialPort();

  childInit();
}

void SerialController::open(const SerialSetting &setting) {
  if (!mSerial) {
    emit serialError("Serial no init");
    return;
  }
  mSerial->setPortName(setting.portName);
  mSerial->setBaudRate(mSupport.baudRates[setting.baudRate]);
  mSerial->setDataBits(mSupport.dataBits[setting.dataBit]);
  mSerial->setStopBits(mSupport.stopBits[setting.stopBit]);
  mSerial->setParity(mSupport.checkBits[setting.checkBit]);

  if (mSerial->open(QIODevice::ReadWrite)) {
    emit serialOpenned();
    connect(mSerial, &QSerialPort::readyRead, this,
            &SerialController::on_readSerial);
  } else {
    emit serialError("Serial Open failed");
  }
}

void SerialController::close() {
  if (!mSerial) {
    emit serialError("Serial no init");
    return;
  }

  if (mSerial->isOpen()) {
    mSerial->close();
    disconnect(mSerial, &QSerialPort::readyRead, this,
               &SerialController::on_readSerial);
    emit serialClosed();
  } else {
    emit serialError("Serial is not open");
  }
}

void SerialController::write(const QString &mesg) {
  if (!mSerial) {
    emit serialError("Serial no init");
    return;
  }

  if (!mSerial->isOpen()) {
    emit serialError("Serial dose not open");
    return;
  }

  mSerial->write(mesg.toUtf8());
  mSerial->waitForBytesWritten(500);
}

void SerialController::on_readSerial() {
  QByteArray raw = mSerial->readAll();

  mSerial->blockSignals(true);
  while (mSerial->waitForReadyRead(100))
    raw += mSerial->readAll();
  mSerial->blockSignals(false);

  emit serialData(raw);

  processRawData(raw);
}
